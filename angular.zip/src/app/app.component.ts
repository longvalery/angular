import { HttpClient } from '@angular/common/http';
import { Component, HostListener, Injectable, ViewChild, OnInit  } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ToastrService, ToastContainerDirective, provideToastr  } from 'ngx-toastr';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent   { // implements OnInit
 title = 'cookies';
 currency = "$";
 currencies = [ ["$", 1] , ["₽", 100], ["BYN", 3] , ["€" , 0.9], ["CNY" , 7]];
 productsData: any; 
 mainImageStyle: any;
 orderImageStyle: any;
 loader:boolean = true;
 loaderShowed: boolean = true;

 /*
 @ViewChild(ToastContainerDirective, { static: true })
  toastContainer!: ToastContainerDirective;
*/  
 /*
 productsData = [
  {
    image: "1.png",
    title: "Лучшие друзья",
    text : "Печенье, с которого все началось! Наше фирменное печенье с шоколадной крошкой и грецкими орехами хрустящее снаружи с достаточно толстой и липкой серединкой.",
    price: 20,
    basePrice: 20,
    weight: "2 шт./ 200 гр.",
  },
  {
    image: "2.png",
    title: "Шоколадный француз",
    text : "Это печенье, изготовленное из тёмного французского какао и полусладкой шоколадной стружки, наверняка удовлетворит даже самого заядлого любителя шоколада.",
    price: 24,
    basePrice: 24,
    weight: "2 шт./ 200 гр.",
  },
  {
    image: "3.png",
    title: "Овсянка с изюмом, Сэр!",
    text : "Это сдобное маслянистое печенье весом шесть унций каждое, золотисто-коричневое снаружи, влажное внутри и наполненное пухлым сладким изюмом.",
    price: 18,
    basePrice: 18,
    weight: "2 шт./ 200 гр.",
  },
  {
    image: "4.png",
    title: "Шоколадное наслаждение",
    text : "Идеально хрустящее снаружи и достаточно густое и липкое в центре, это печенье наполнено полусладкой и тёмной шоколадной стружкой, придающей богатую глубину вкуса.",
    price: 24,
    basePrice: 24,
    weight: "2 шт./ 200 гр.",
  },
  {
    image: "5.png",
    title: "Арахисовый рай",
    text : "Сладкое, пикантное и идеально сбалансированное печенье удовлетворяет тягу любителей арахисового масла и шоколада.",
    price: 20,
    basePrice: 20,
    weight: "2 шт./ 200 гр.",
  },
  {
    image: "6.png",
    title: "Шоколадный ореховый деликатес",
    text : "Наша фирменная рецептура печенья с шоколадными крошками и грецкими орехами гарантирует незабываемый вкусовой опыт. Каждое печенье хрустит снаружи, но раскрывает внутри нежную сердцевину.",
    price: 18,
    basePrice: 18,
    weight: "2 шт./ 200 гр.",
  },
  {
    image: "7.png",
    title: "Ассорти фирменного печенья",
    text : "Зачем выбирать один, когда можно получить их все? Наш классический ассортимент печенья включает в себя по одному из четырёх оригинальных вкусов печенья.",
    price: 36,
    basePrice: 36,
    weight: "4 шт./ 400 гр.",
  },
  {
    image: "8.png",
    title: "Лимонное печенье",
    text : "Весна уже не за горами, но нам не терпелось подарить вам немного солнечного света: наше первое лимонное печенье. Это лакомство жевательное, лимонное, не слишком сладкое и даже немного… освежающее?",
    price: 33,
    basePrice: 33,
    weight: "4 шт./ 400 гр.",
  },
  {
    image: "9.png",
    title: "Любители шоколада",
    text : "Вам больше не нужно выбирать фаворитов. Мы сделали этот набор для всех людей, которые действительно любят шоколад…",
    price: 38,
    basePrice: 38,
    weight: "4 шт./ 400 гр.",
  },
  {
    image: "10.png",
    title: "Карамель и кокос",
    text : "Побалуйте себя кокосовым, маслянистым, карамельным печеньем, которое обладает невиданным ранее вкусом и текстурой. Наслаждение круглый год.",
    price: 33,
    basePrice: 33,
    weight: "4 шт./ 400 гр.",
  },
  {
    image: "11.png",
    title: "Веганское с шоколадной крошкой",
    text : "Наше веганское безглютеновое печенье содержит кусочки хрустящих грецких орехов и полусладкую веганскую шоколадную стружку.",
    price: 39,
    basePrice: 39,
    weight: "4 шт./ 400 гр.",
  },
  {
    image: "12.png",
    title: "Крем-брюле ореховое печенье",
    text : "Используя уникальную смесь ингредиентов, мы создали печенье с кусочками крем-брюле и миндальными орехами, которое обещает неповторимые гастрономические ощущения. Каждый кусочек обладает хрустящей корочкой и тает во рту.",
    price: 35,
    basePrice: 35,
    weight: "4 шт./ 400 гр.",
  },  
 ];
*/

 form= this.fb.group({
  cookiesOrder: ["", Validators.required],
  nameOrder: ["", Validators.required],
  phoneOrder: ["", Validators.required, //Validators.pattern("^[0-9]*$") //, 
                  // Validators.minLength(6), Validators.maxLength(10)
              ],
 });
 
 @HostListener ("document:mousemove",["$event"]) 
 onMouseMove(e: MouseEvent) {
   this.mainImageStyle  = {transform: "translate("  + ((e.clientX * 0.3) / 8) + "px, "  + ((e.clientY * 0.3) / 8) + "px"};
   this.orderImageStyle = {transform: "translate(-" + ((e.clientX * 0.3) / 8) + "px, -" + ((e.clientY * 0.3) / 8) + "px"};
                            }

   constructor(private fb:FormBuilder, private http: HttpClient, private toasterService:  ToastrService) {
  }

  showToaster(message:string, title:string )  {
    this.toasterService.success(message, title);
    console.log(message, title);
  }  
  
  showSuccess() {
    this.toasterService.success('Hello world!', 'Toastr fun!', {timeOut: 3000}); // , newestOnTop:true, positionClass: 'toast-top-center'
    console.log("Hello world!");
  }

  ngOnInit() {
    this.http.get("https://testologia.ru/cookies")
        .subscribe(data => { this.productsData = data; this.changeCurrency(); } );
  //  this.toasterService.overlayContainer = this.toastContainer;
    setTimeout(() => { this.loaderShowed = false}, 2000);
    setTimeout(() => { this.loader = false; }, 3000);
    // setTimeout(() => { this.showSuccess();  }, 5000);
    
             }

  confirmOrder(){
    if (this.form.valid) {
       const username = (<HTMLInputElement>document.getElementById("nameOrder")).value;
       //alert(username +  " !Спасибо за заказ! Мы скоро свяжемся с Вами!"); 
       const request = {product: this.form.value.cookiesOrder, name: this.form.value.nameOrder, phone:this.form.value.phoneOrder};
       this.http.post( "https://testologia.ru/cookies-order", request)
                .subscribe({
                  next: (response:any) => {
                    // alert(username +  " " + response.message);
                    // this.showToaster(username +  "! " + response.message, "Trendy cookies");
                    this.toasterService.success(username +  "! " + response.message, "Trendy cookies"
                       , {timeOut: 10000, closeButton:true,  titleClass: "custom-toast-title", messageClass: "custom-toast-message"});
                    this.form.reset(); 
                                          },                      
                  error: (response:any) => {
                    alert(username +  " " + response.error.message);
                                           },                      
                           });
       
                         }
  }

  switchSugarFree(e: any) {
    this.http.get("https://testologia.ru/cookies" + (e.currentTarget.checked ? '?sugarfree' : ''))
      .subscribe(data => this.productsData = data);
  }

  scrollTo(target: HTMLElement, product?: any){
    target.scrollIntoView({behavior: "smooth"});
    if (product) {
      this.form.patchValue({cookiesOrder: product.title + ' (' + product.price + ' ' + this.currency + ')'});
    }
                               }

  changeCurrency() {
    let index = 0;
    for (let i = 0; i < this.currencies.length; i++) {
        if (this.currencies[i][0] === this.currency) {
            if ((i+1) == this.currencies.length) { index = 0 }
            else { index = i + 1; break; }    
                                                  }
                                                    }
    this.currency = this.currencies[index][0] as string;
    this.productsData.forEach((item:any) => {
      item.price = + (item.basePrice * (this.currencies[index][1] as number)).toFixed(1) + 
                 " " + this.currencies[index][0] as string ;
                                            })
                   }

    
}
/*
@Injectable({
  providedIn: 'root',
})
class ToasterService {
  [x: string]: ToastContainerDirective;

  constructor(private toastr: ToastrService) { 

  }

  success(message: string, title?: string) {
    this.toastr.success(message, title);
    console.log(message, title);
  }

  error(message: string, title?: string) {
    this.toastr.error(message, title);
  }

  warning(message: string, title?: string) {
    this.toastr.warning(message, title);
  }

  info(message: string, title?: string) {
    this.toastr.info(message, title);
  }

}
*/